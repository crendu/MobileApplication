package com.esilv.finalproject_clementrendu.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.esilv.finalproject_clementrendu.R;
import com.esilv.finalproject_clementrendu.model.VideoItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Clement on 17/03/2017.
 */

public class TestAdapter extends RecyclerView.Adapter<TestAdapter.TestHolder> {
    private List<VideoItem> videoData;
    private LayoutInflater inflater;
    private ItemClickCallback itemClickCallback;

    public interface ItemClickCallback {
        void onItemClick(int p);
        void onSecondaryIconClick(int p);
    }

    public void setItemClickCallback(final ItemClickCallback itemClickCallback) {
        this.itemClickCallback = itemClickCallback;
    }

    public TestAdapter (List<VideoItem> videoData, Context c) {
        this.inflater = LayoutInflater.from(c);
        this.videoData = videoData;
    }

    @Override
    public TestHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.video_item, parent, false);
        return new TestHolder(view);
    }

    @Override
    public void onBindViewHolder(TestHolder holder, int position) {
        VideoItem item = videoData.get(position);
        //holder.title.setText(item.getTitle());
        //holder.subTitle.setText(item.getSubTitle());

        if(item.isFavourite()) {
            holder.secondaryIcon.setImageResource(R.drawable.ic_star_black_24dp);
        } else {
            holder.secondaryIcon.setImageResource(R.drawable.ic_star_border_black_24dp);
        }
    }

    public void setVideoData(ArrayList<VideoItem> exerciseList) {
        this.videoData.clear();
        this.videoData.addAll(exerciseList);
    }

    @Override
    public int getItemCount() {
        return videoData.size();
    }

    class TestHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView title;
        private TextView subTitle;
        private ImageView thumbnail;
        private ImageView secondaryIcon;
        private View container;

        public TestHolder(View itemView) {
            super(itemView);

            //title = (TextView)itemView.findViewById(R.id.lbl_item_text);
            //subTitle = (TextView)itemView.findViewById(R.id.lbl_item_sub_title);
            //thumbnail = (ImageView)itemView.findViewById(R.id.im_item_icon);
            secondaryIcon = (ImageView)itemView.findViewById(R.id.im_item_icon_secondary);
            secondaryIcon.setOnClickListener(this);
            container = itemView.findViewById(R.id.cont_item_root);
            container.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if(v.getId() == R.id.cont_item_root) {
                itemClickCallback.onItemClick(getAdapterPosition());
            } else {
                itemClickCallback.onSecondaryIconClick(getAdapterPosition());
            }
        }
    }
}
