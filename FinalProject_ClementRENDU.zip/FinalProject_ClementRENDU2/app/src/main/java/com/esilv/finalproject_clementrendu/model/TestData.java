package com.esilv.finalproject_clementrendu.model;

import com.esilv.finalproject_clementrendu.R;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;

import java.util.ArrayList;
import java.util.List;

/**
 * display RecyclerView
 * Created by Clement on 17/03/2017.
 */

public class TestData {
    private static final String kind = "A";
    private static final String etag = "B";
    private static final String videoTitle = "C";
    private static final String channelTitle = "D";
    private static final String description = "E";
    private static final int icon = R.drawable.ic_camera_black_36dp;
    private static Gson gson;
    private static AsyncHttpClient client;

    public static List<VideoItem> getListData() {
        List<VideoItem> data = new ArrayList<>();

        //Repeat process 10 times, so the list is compose with 10 cells
        for (int i = 0; i < 10; i++) {
            VideoItem item = new VideoItem();

            //String qtext = qtxt.replaceAll("\\s", "+");
            //String url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q='" + qtext + "'&type=video&";
            String url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=cat&type=video&";
            String apiKey = "AIzaSyBhBKj1YJrqjWLq6_6u2uayuQfdaCPKTWQ";
            String urlJSON = url + "key=" + apiKey;

            client = new AsyncHttpClient();
            //client.get();

            item.setKind(kind);
            item.setEtag(etag);
            item.setVideoTitle(videoTitle);
            item.setChannelTitle(channelTitle);
            item.setDescription(description);
            data.add(item);
        }
        return data;
    }
}
        
        