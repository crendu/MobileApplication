package com.esilv.finalproject_clementrendu.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.esilv.finalproject_clementrendu.R;
import com.esilv.finalproject_clementrendu.adapter.TestAdapter;
import com.esilv.finalproject_clementrendu.model.TestData;
import com.esilv.finalproject_clementrendu.model.VideoItem;

import java.util.ArrayList;

public class ListActivity  extends AppCompatActivity implements TestAdapter.ItemClickCallback {
    private static final String BUNDLE_EXTRAS = "BUNDLE_EXTRAS";
    private static final String EXTRA_QUOTE = "EXTRA_QUOTE";
    private static final String EXTRA_ATTR = "EXTRA_ATTR";
    private RecyclerView recView;
    private TestAdapter adapter;
    private ArrayList videoData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        videoData = (ArrayList)TestData.getListData();

        recView = (RecyclerView)findViewById(R.id.rec_list);
        //LayoutManager : GridLayoutManager or StaggeredGridLayoutManager
        recView.setLayoutManager(new LinearLayoutManager(this ));

        adapter = new TestAdapter(videoData, this);
        recView.setAdapter(adapter);
        adapter.setItemClickCallback(this);
    }

    @Override
    public void onItemClick(int p) {
        VideoItem item = (VideoItem)videoData.get(p);
        Intent i = new Intent(this, DetailActivity.class);

        Bundle extras = new Bundle();
        //extras.putString(EXTRA_QUOTE, item.getTitle());
        //extras.putString(EXTRA_ATTR, item.getSubTitle());

        i.putExtra(BUNDLE_EXTRAS, extras);
        startActivity(i);
    }

    @Override
    public void onSecondaryIconClick(int p) {
        VideoItem item = (VideoItem)videoData.get(p);
        //update our data
        if(item.isFavourite()) {
            item.setFavourite(false);
        } else {
            item.setFavourite(true);
        }
        //pass new data to adapter and update
        adapter.setVideoData(videoData);
        adapter.notifyDataSetChanged();
    }
}
